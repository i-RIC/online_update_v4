def f(elevation, depth, wse, vx, vy, val1, val2, v):
    return depth
