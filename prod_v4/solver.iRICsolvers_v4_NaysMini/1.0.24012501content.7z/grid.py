import numpy as np
import sys
import iric

