<?xml version="1.0" encoding="UTF-8"?>
<TS version="2.0" language="ja_JP">
    <!--これは iRIC で使用する辞書ファイルです。
<translation> と </translation> の間に、翻訳後の文字列を追記してください。
-->
    <context>
        <message>
            <source>RiTER Xsec</source>
            <translation>RiTER Xsec</translation>
        </message>
        <message>
            <source>Basic Setting</source>
            <translation>基本設定</translation>
        </message>
        <message>
            <source>Output csv for cross-section</source>
            <translation>断面の結果をCSVに出力</translation>
        </message>
        <message>
            <source>CSV file name</source>
            <translation>CSVファイル名</translation>
        </message>
        <message>
            <source>Elevation (before)</source>
            <translation>標高 (変更前)</translation>
        </message>
        <message>
            <source>Elevation (after)</source>
            <translation>標高 (変更後)</translation>
        </message>
        <message>
            <source>Target Area</source>
            <translation>集計対象領域</translation>
        </message>
        <message>
            <source>Not Target</source>
            <translation>非対象</translation>
        </message>
        <message>
            <source>Target</source>
            <translation>対象</translation>
        </message>
    </context>
</TS>
